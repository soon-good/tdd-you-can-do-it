package io.study.tdd.webflux_study;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WebfluxStudyApplication {

	public static void main(String[] args) {
		SpringApplication.run(WebfluxStudyApplication.class, args);
	}

}
