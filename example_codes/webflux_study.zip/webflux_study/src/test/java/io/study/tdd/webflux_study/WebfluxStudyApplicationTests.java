package io.study.tdd.webflux_study;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebfluxStudyApplicationTests {

	@Test
	void contextLoads() {
	}

}
